/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ucompensar.codigo;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 *
 * @author NicolasAlejandroPere
 */
public class Principal {

    public record Estudiante(String nombre, String programa, double nota) {

    }

    public static void main(String[] args) {

        List<Estudiante> estudiantes = List.of(
                new Estudiante("Ana", "Sistemas", 2.5),
                new Estudiante("Carlos", "Sistemas", 5.0),
                new Estudiante("Alberto", "Derecho", 3.2),
                new Estudiante("Beatriz", "Medicina", 2.8),
                new Estudiante("Daniel", "Sistemas", 4.0),
                new Estudiante("Elena", "Derecho", 2.0),
                new Estudiante("Fernando", "Medicina", 4.5),
                new Estudiante("Gabriela", "Sistemas", 3.2),
                new Estudiante("Hugo", "Derecho", 3.8),
                new Estudiante("Irene", "Medicina", 2.5)
        );

        double notaAprov = 3.0;
        Scanner tec = new Scanner(System.in);
        boolean salir = false;
        do {
            System.out.println("\nMENU DE OPCIONES");
            System.out.println("1. Mostrar la lista original ");
            System.out.println("2. Estudiantes aprobados y desaprobados");
            System.out.println("3. Ordenar por nota desendente");
            System.out.println("4. Ordenar por nombre");
            System.out.println("5. Los 3 mejores promedios");
            System.out.println("6. Promedio general");
            System.out.println("7. Agrupar por programa y calcular promedio del grupo");
            System.out.println("8. salir");

            int option = tec.nextInt();
            switch (option) {
                case 1:
                    System.out.println("\nLa lista de estudiantes es: ");
                    estudiantes.forEach(System.out::println);

                    break;
                case 2:
                    System.out.println("\nEstudiantes aprobados y desaprobados:");

                    Map<Boolean, List<Estudiante>> particionAprobados = estudiantes.stream()
                            .collect(Collectors.partitioningBy(e -> e.nota() >= notaAprov));

                    System.out.println("Aprobados:");
                    particionAprobados.get(true).forEach(e -> System.out.println("  " + e));
                    System.out.println("Reprobados:");
                    particionAprobados.get(false).forEach(e -> System.out.println("  " + e));

                    break;
                case 3:
                    System.out.println("\nEstudiantes ordenados por nota descendente:");
                    estudiantes.stream()
                            .sorted(Comparator.comparingDouble(Estudiante::nota).reversed())
                            .forEach(e -> System.out.println("  " + e));
                    break;
                case 4:
                    System.out.println("\nEstudiantes ordenados por nombre:");
                    estudiantes.stream()
                            .sorted(Comparator.comparing(Estudiante::nombre))
                            .forEach(e -> System.out.println("  " + e));
                    break;
                case 5:
                    System.out.println("\nLos 3 mejores promedios:");
                    estudiantes.stream()
                            .sorted(Comparator.comparingDouble(Estudiante::nota).reversed())
                            .limit(3)
                            .forEach(e -> System.out.println("  " + e));
                    break;
                case 6:
                    double promedioGeneral = estudiantes.stream()
                            .mapToDouble(Estudiante::nota)
                            .average()
                            .orElse(0.0);
                    System.out.println("\nPromedio general de la clase: " + promedioGeneral);
                    break;
                case 7:
                    System.out.println("\nPromedio por programa:");
                    Map<String, Double> promedioPorPrograma = estudiantes.stream()
                            .collect(Collectors.groupingBy(
                                    Estudiante::programa,
                                    Collectors.averagingDouble(Estudiante::nota)
                            ));
                    
                    promedioPorPrograma.forEach((programa, promedio) -> 
                        System.out.println("  Programa: " + programa + " - Promedio: " + promedio)
                    );
                    break;
                case 8:
                    System.out.println("Saliendo del sistema...");
                    salir = true;
                    break;
                default:
                    System.out.println("Opcion no valida");
            }
        } while (!salir);

        tec.close();
    }
}
