/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package procesamientolistas;

import java.util.ArrayList;

import java.util.Scanner;

/**
 *
 * @author NicolasAlejandroPerez
 */
public class ProcesamientoListas {

    public static class Productos {

        private int codigo;
        private String nombre;
        private String categoria;
        private double precio;
        private int stock;

        public Productos(int codigo, String nombre, String categoria,
                double precio, int stock) {
            this.codigo = codigo;
            this.nombre = nombre;
            this.categoria = categoria;
            this.precio = precio;
            this.stock = stock;
        }

        public int getCodigo() {
            return codigo;
        }

        public String getNombre() {
            return nombre;
        }

        public String getCategoria() {
            return categoria;
        }

        public double getPrecio() {
            return precio;
        }

        public int getStock() {
            return stock;
        }

        public void setPrecio(double precio) {
            this.precio = precio;
        }

        public void setStock(int stock) {
            this.stock = stock;
        }

        @Override
        public String toString() {
            return codigo + " - " + nombre
                    + " - " + categoria
                    + " - $" + precio
                    + " - Stock: " + stock;
        }
    }

    public static void main(String[] args) {

        ArrayList<Productos> productos = new ArrayList<>();

        productos.add(new Productos(101, "Portátil", "Tecnología", 3200, 8));
        productos.add(new Productos(102, "Mouse", "Tecnología", 80, 25));
        productos.add(new Productos(103, "Teclado", "Tecnología", 120, 12));
        productos.add(new Productos(104, "Cuaderno", "Papelería", 15, 50));
        productos.add(new Productos(105, "Marcadores", "Papelería", 28, 30));
        productos.add(new Productos(106, "Impresora", "Tecnología", 950, 4));
        productos.add(new Productos(107, "Escritorio", "Muebles", 680, 6));
        productos.add(new Productos(108, "Silla", "Muebles", 450, 10));
        productos.add(new Productos(109, "Monitor", "Tecnología", 780, 9));
        productos.add(new Productos(110, "Disco SSD 1TB", "Tecnología", 350, 15));
        productos.add(new Productos(111, "Memoria USB 64GB", "Tecnología", 45, 40));
        productos.add(new Productos(112, "Router WiFi", "Tecnología", 220, 11));
        productos.add(new Productos(113, "Cable HDMI", "Tecnología", 35, 60));
        productos.add(new Productos(114, "Webcam", "Tecnología", 160, 13));
        productos.add(new Productos(115, "Audífonos", "Tecnología", 140, 20));
        productos.add(new Productos(116, "Micrófono", "Tecnología", 190, 7));
        productos.add(new Productos(117, "Calculadora Científica", "Papelería", 65, 18));
        productos.add(new Productos(118, "Resaltadores", "Papelería", 18, 35));
        productos.add(new Productos(119, "Carpeta", "Papelería", 12, 80));
        productos.add(new Productos(120, "Lápiz", "Papelería", 3, 200));
        productos.add(new Productos(121, "Bolígrafo", "Papelería", 5, 150));
        productos.add(new Productos(122, "Borrador", "Papelería", 2, 120));
        productos.add(new Productos(123, "Regla", "Papelería", 8, 45));
        productos.add(new Productos(124, "Archivador", "Papelería", 25, 20));
        productos.add(new Productos(125, "Mesa de Reuniones", "Muebles", 1500, 3));
        productos.add(new Productos(126, "Biblioteca", "Muebles", 1200, 5));
        productos.add(new Productos(127, "Archivador Metálico", "Muebles", 890, 4));
        productos.add(new Productos(128, "Sofá de Oficina", "Muebles", 2100, 2));
        productos.add(new Productos(129, "Lámpara de Escritorio", "Muebles", 95, 14));
        productos.add(new Productos(130, "Ventilador", "Electrodomésticos", 180, 8));
        productos.add(new Productos(131, "Cafetera", "Electrodomésticos", 320, 6));
        productos.add(new Productos(132, "Horno Microondas", "Electrodomésticos", 550, 4));
        productos.add(new Productos(133, "Nevera Ejecutiva", "Electrodomésticos", 980, 2));
        productos.add(new Productos(134, "Tablet", "Tecnología", 1300, 7));
        productos.add(new Productos(135, "Smartphone", "Tecnología", 2200, 5));
        System.out.println("PUNTO 1");
        System.out.println("\nCantidad de productos registrados: " + productos.size());

        double suma = 0;
        for (Productos p : productos) {
            suma += p.getPrecio();

        }

        double Promedio = suma / productos.size();
        System.out.printf("\nValor promedio de los precios: $%.2f%n", Promedio);

        Productos productoMayor = productos.get(0);

        for (Productos p : productos) {
            if (p.getPrecio() > productoMayor.getPrecio()) {
                productoMayor = p;
            }
        }
        System.out.println("\nEl producto de mayor precio es: " + productoMayor);

        Productos productoMenor = productos.get(0);

        for (Productos p : productos) {
            if (p.getPrecio() < productoMenor.getPrecio()) {
                productoMenor = p;
            }
        }
        System.out.println("\nEl producto de menor precio es: " + productoMenor);

        System.out.println("\nLos productos cuyo stock es menor a 10 son :");
        int contador = 0;

        for (Productos p : productos) {
            if (p.getStock() < 10) {
                contador++;

                System.out.print(p.getNombre() + ". ");
            }

        }
        System.out.println("\nPara una candidad de " + contador + " productos");

        System.out.println("\nPUNTO 2");

        ArrayList<Productos> productosTecnologia = new ArrayList<>();

        for (Productos p : productos) {
            if (p.getCategoria().equals("Tecnología")) {
                productosTecnologia.add(p);
            }
        }
        System.out.println("\nLos productos que pertenecen a Tecnologia son:");
        System.out.println(productosTecnologia);

        ArrayList<Productos> productosEconomicos = new ArrayList<>();
        for (Productos p : productos) {
            if (p.getPrecio() < 200) {
                productosEconomicos.add(p);
            }
        }
        System.out.println("\nLos productos economicos con precio menor a 200 son: ");
        System.out.println(productosEconomicos);

        double totalTecnologia = 0.0;
        for (Productos p : productosTecnologia) {
            totalTecnologia += p.getPrecio() * p.getStock();
        }
        System.out.printf("\nValor total del inventario de tecnología: $%.2f%n", totalTecnologia);

        double totalEconomicos = 0.0;
        for (Productos p : productosEconomicos) {
            totalEconomicos += p.getPrecio() * p.getStock();
        }
        System.out.printf("\nValor total del inventario de tecnología: $%.2f%n", totalEconomicos);

        System.out.println("\nPUNTO 3");

        Scanner scanner = new Scanner(System.in);

        int opcion;

        do {
            System.out.println("\nMENÚ DE INVENTARIO");
            System.out.println("1. Buscar producto por código");
            System.out.println("2. Actualizar precio");
            System.out.println("3. Actualizar stock");
            System.out.println("4. Eliminar producto");
            System.out.println("5. Mostrar inventario");
            System.out.println("6. Mostrar productos por categoría");
            System.out.println("7. Salir");
            System.out.print("\nElige una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.println("\nBUSCAR PRODUCTO");
                    int productoActual = scanner.nextInt();
                    for (Productos p : productos) {
                        if (p.getCodigo() == productoActual) {
                            System.out.println("\nProducto encontrado: " + p);
                        }
                    }

                    break;

                case 2:
                    System.out.println("\nACTUALIZAR PRECIO");
                    System.out.print("Ingrese el código del producto que desea actualizar: ");
                    int codigoBuscado = scanner.nextInt();
                    boolean encontradoPrecio = false;

                    for (Productos p : productos) {
                        if (p.getCodigo() == codigoBuscado) {
                            System.out.print("Ingrese el nuevo precio: ");
                            double nuevoPrecio = scanner.nextDouble();
                            p.setPrecio(nuevoPrecio);
                            System.out.println("¡Precio actualizado con éxito!");
                            encontradoPrecio = true;
                            break;
                        }
                    }

                    if (!encontradoPrecio) {
                        System.out.println("No se encontró ningún producto con ese código.");
                    }

                    break;

                case 3:
                    System.out.println("\nACTUALIZAR STOCK");
                    System.out.print("Ingrese el código del producto cuyo stock desea actualizar: ");
                    int codigoStock = scanner.nextInt();
                    boolean encontradoStock = false;

                    for (Productos p : productos) {
                        if (p.getCodigo() == codigoStock) {
                            System.out.print("Ingrese el nuevo stock: ");
                            int nuevoStock = scanner.nextInt();
                            p.setStock(nuevoStock);
                            System.out.println("¡Stock actualizado con exito!");
                            encontradoStock = true;
                            break;
                        }
                    }

                    if (!encontradoStock) {
                        System.out.println("No se encontro ningun producto con ese codigo.");
                    }
                    break;

                case 4:
                    System.out.println("\nELIMINAR PRODUCTO");
                    System.out.print("Ingrese el codigo del producto que desea eliminar: ");
                    int codigoEliminar = scanner.nextInt();
                    boolean eliminado = false;

                    for (int i = 0; i < productos.size(); i++) {
                        if (productos.get(i).getCodigo() == codigoEliminar) {
                            productos.remove(i);
                            System.out.println("¡Producto eliminado con exito!");
                            eliminado = true;
                            break;
                        }
                    }

                    if (!eliminado) {
                        System.out.println("No se encontró ningún producto con ese codigo.");
                    }
                    break;
                case 5:
                    System.out.println("\nINVENTARIO ACTUAL");
                    if (productos.isEmpty()) {
                        System.out.println("El inventario esta vacio.");
                    } else {
                        for (Productos p : productos) {
                            System.out.println(p);
                        }
                    }
                    break;
                case 6:
                    System.out.println("\nPRODUCTOS POR CATEGORIA");
                    System.out.print("Ingrese la categoria que desea consultar: ");
                    scanner.nextLine();
                    String categoriaBuscada = scanner.nextLine();
                    boolean categoriaEncontrada = false;

                    for (Productos p : productos) {
                        if (p.getCategoria().equalsIgnoreCase(categoriaBuscada)) {
                            System.out.println(p);
                            categoriaEncontrada = true;
                        }
                    }

                    if (!categoriaEncontrada) {
                        System.out.println("No se encontraron productos en esa categoria.");
                    }
                    break;
                case 7:
                    System.out.println("¡Hasta luego!");
                    break;

                default:
                    System.out.println("Opcion no valida. Intentalo de nuevo.");
            }
        } while (opcion != 7);
    }
}
